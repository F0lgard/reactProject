import React from "react";
import "../styles/DeviceButton.css"; // Підключаємо окремий файл стилів
import pcMonitorIcon from "../img/pcMonitor.png"; // Імпортуємо зображення
import controllerIcon from "../img/controller.png"; // Імпортуємо зображення для контролера

const DeviceButton = ({ id, type, isBooked, onClick, position }) => {
  const bgColor = isBooked ? "bg-red-600" : "bg-green-600";
  const icon = type === "pc" ? pcMonitorIcon : controllerIcon; // Використовуємо імпортовані іконки

  return (
    <button
      className={`device-button ${bgColor}`}
      onClick={() => onClick(id)}
      style={{
        position: "absolute",
        top: `${position.top}px`,
        left: `${position.left}px`,
      }}
    >
      <div className="icon-container">
        <img src={icon} alt={type} className="device-icon" />
      </div>
      <span className="device-id">{id}</span>
    </button>
  );
};

export default DeviceButton;
