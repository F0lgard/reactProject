import React, { useState } from "react";
import DeviceButton from "./DeviceButton"; // Імпортуємо компонент кнопки
import "../styles/Map.css";

const MapSection = () => {
  const [bookedDevices, setBookedDevices] = useState([]);

  const handleClick = (id) => {
    setBookedDevices((prev) =>
      prev.includes(id) ? prev.filter((device) => device !== id) : [...prev, id]
    );
  };

  // Створення масивів пристроїв для різних зон з унікальними ID
  const proZoneDevices = Array.from({ length: 12 }, (_, index) => ({
    id: `ПК${index + 1}P`,
    type: "pc",
    position: {
      top: 44 + Math.floor(index / 4) * 98,
      left: 503 + (index % 4) * 94,
    },
  }));

  const vipZoneDevices = Array.from({ length: 8 }, (_, index) => ({
    id: `ПК${index + 1}V`,
    type: "pc",
    position: {
      top: 44 + Math.floor(index / 4) * 127,
      left: 20 + (index % 4) * 94,
    },
  }));

  const consoleDevices = Array.from({ length: 4 }, (_, index) => ({
    id: `PS${index + 1}`,
    type: "ps",
    position: {
      top: 426 + Math.floor(index / 4) * 50,
      left: 31 + index * 112,
    },
  }));

  // Об'єднання всіх пристроїв в один масив
  const devices = [...proZoneDevices, ...vipZoneDevices, ...consoleDevices];

  return (
    <div className="map-section">
      <h2 className="map-section-name">Мапа</h2>
      <div className="map-container">
        <h2 className="map-text">
          Щоб забронювати ПК чи Консоль, натисніть по відповідній зеленій
          іконці.
        </h2>
        <div className="map-wrapper">
          {/* Мапа */}
          <img
            src={require("../img/mainMap.png")}
            alt="Мапа приміщення"
            className="map-schema"
          />
          {/* Кнопки ПК та консолей */}
          {devices.map((device) => (
            <DeviceButton
              key={device.id}
              id={device.id}
              type={device.type}
              isBooked={bookedDevices.includes(device.id)}
              onClick={handleClick}
              position={device.position} // Передаємо позицію
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default MapSection;
