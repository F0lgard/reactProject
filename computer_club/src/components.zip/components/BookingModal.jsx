import React, { useState } from "react";
import Modal from "./Modal";
import "../styles/Modal.css";
import { useAuth } from "./AuthContext";
import { useBookings } from "./BookingsContext";

const BookingModal = ({ isActive, onClose, selectedDevice }) => {
  const { isAuthenticated, user } = useAuth();
  const { addBooking } = useBookings();
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [selectedTime, setSelectedTime] = useState("12:00");
  const [bookingError, setBookingError] = useState("");

  const handleReserve = async () => {
    if (!selectedDevice) return;
    if (!selectedDate || !selectedTime) {
      setBookingError("Будь ласка, виберіть дату та час.");
      return;
    }

    const bookingData = {
      device: selectedDevice.name,
      userId: user._id,
      date: selectedDate,
      time: selectedTime,
    };

    try {
      // Імітація API запиту на бронювання
      console.log("Booking successful:", bookingData);
      addBooking(bookingData);
      onClose();
    } catch (error) {
      console.error("Error booking:", error);
    }
  };

  return (
    <Modal isActive={isActive} onClose={onClose}>
      <h2>Бронювання {selectedDevice?.name}</h2>
      <label>
        Дата:
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
        />
      </label>
      <label>
        Час:
        <input
          type="time"
          value={selectedTime}
          onChange={(e) => setSelectedTime(e.target.value)}
        />
      </label>
      {bookingError && <p className="error">{bookingError}</p>}
      <button onClick={handleReserve}>Забронювати</button>
    </Modal>
  );
};

const InfoModal = ({ isActive, onClose, selectedDevice }) => {
  return (
    <Modal isActive={isActive} onClose={onClose}>
      <h2>Інформація про {selectedDevice?.name}</h2>
      <p>Цей пристрій вже заброньований на вибраний час.</p>
      <button onClick={onClose}>Закрити</button>
    </Modal>
  );
};

export { BookingModal, InfoModal };
