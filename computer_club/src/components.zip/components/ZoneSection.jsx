// import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import Slider from './Slider';


export default function ZoneSection() {

return (
    <section className='zone-section' id="zoneSection">
        <Slider />
    </section>
    )
}